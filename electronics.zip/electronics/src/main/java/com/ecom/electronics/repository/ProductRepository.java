package com.ecom.electronics.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecom.electronics.model.Product;

public interface ProductRepository extends JpaRepository<Product, Integer>{

}
