package com.ecom.electronics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElectronicsApplicationTests {

	@Test
	void contextLoads() {
	}

}
